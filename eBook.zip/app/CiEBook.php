<?php

namespace App;

class CiEBook
{
    /**
     * The CiEBook version.
     *
     * @var string
     */
    const VERSION = '2.0.4';
}
