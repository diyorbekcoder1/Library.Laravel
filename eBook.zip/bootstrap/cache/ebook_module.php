<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Ebook\\Providers\\EbookServiceProvider',
    1 => 'Modules\\Ebook\\Providers\\EventServiceProvider',
    2 => 'Modules\\Ebook\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Ebook\\Providers\\EbookServiceProvider',
    1 => 'Modules\\Ebook\\Providers\\EventServiceProvider',
    2 => 'Modules\\Ebook\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);