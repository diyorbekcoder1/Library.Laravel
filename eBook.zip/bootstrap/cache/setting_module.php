<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Setting\\Providers\\SettingServiceProvider',
    1 => 'Modules\\Setting\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Setting\\Providers\\SettingServiceProvider',
    1 => 'Modules\\Setting\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);