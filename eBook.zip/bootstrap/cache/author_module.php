<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Author\\Providers\\AuthorServiceProvider',
    1 => 'Modules\\Author\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Author\\Providers\\AuthorServiceProvider',
    1 => 'Modules\\Author\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);