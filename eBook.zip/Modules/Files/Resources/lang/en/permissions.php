<?php

return [
    
    'files' => [
        'index' => 'Index Files',
        'create' => 'Create Files',
        'edit' => 'Edit Files',
        'destroy' => 'Delete Files',
    ],
    
];
