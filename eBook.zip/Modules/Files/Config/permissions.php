<?php

return [
    'admin.files' => [
        'index' => 'files::permissions.files.index',
        'create' => 'files::permissions.files.create',
        //'edit' => 'files::permissions.files.edit',
        'destroy' => 'files::permissions.files.destroy',
    ],  
];
