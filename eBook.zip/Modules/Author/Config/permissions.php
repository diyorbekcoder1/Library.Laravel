<?php

return [
    'admin.authors' => [
        'index' => 'author::permissions.index',
        'create' => 'author::permissions.create',
        'edit' => 'author::permissions.edit',
        'destroy' => 'author::permissions.destroy',
    ],
];
