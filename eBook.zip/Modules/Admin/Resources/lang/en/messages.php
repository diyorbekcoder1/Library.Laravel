<?php

return [
    'saved_message' => ':resource has been saved.',
    'update_message' => ':resource has been updated.',
    'deleted_message' => ':resource has been deleted.',
    'permission_denied' => 'Permission Denied (required permission: ":permission").',
];
