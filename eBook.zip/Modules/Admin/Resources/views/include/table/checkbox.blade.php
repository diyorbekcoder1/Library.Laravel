<div class="custom-control custom-checkbox">
    <input type="checkbox" class="select-row custom-control-input" value="{{ $entity->id }}" id="{{ $id = str_random() }}">
    <label class="custom-control-label" for="{{ $id }}"></label>
</div>