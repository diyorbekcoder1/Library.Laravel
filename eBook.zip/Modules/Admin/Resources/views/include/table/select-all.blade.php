<th>
    <div class="custom-control custom-checkbox">
        <input type="checkbox" class="select-all custom-control-input" id="{{ $name ?? '' }}-select-all">
        <label class="custom-control-label" for="{{ $name ?? '' }}-select-all"></label>
    </div>
</th>
