<?php

return [
   
    'all_assets' => [
        'admin.css' => ['module' => 'admin:css/admin.css'],
        'admin.js' => ['module' => 'admin:js/admin.js'],
    ],

    'required_assets' => ['admin.css', 'admin.js'],
];
