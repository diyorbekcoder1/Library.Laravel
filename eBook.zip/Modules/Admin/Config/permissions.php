<?php

return [
    'admin.activity' => [
        'index' => 'admin::permissions.activity.index',
    ],
    
];
