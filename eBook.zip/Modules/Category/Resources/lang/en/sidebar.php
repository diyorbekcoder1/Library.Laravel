<?php

return [
    'categories' => 'Categories',
];
