@include('meta::admin.meta_fields', ['entity' => $ebook])
   