<?php

return [
    'ebooks' => 'eBooks',
    'reportedebooks' => 'Reported eBooks',
    'reports' => 'Reports',
    'most_viewed_ebooks' => 'Most Viewed eBooks',
    'pre_book_visitor' => 'Pre Book Visitor',
    
    
];
