<?php

return [
    'index' => 'Index ebooks',
    'create' => 'Create ebooks',
    'edit' => 'Edit ebooks',
    'destroy' => 'Delete ebooks',
    'reportedindex' => 'Index Reported ebooks',
    'reporteddestroy' => 'Delete Reported ebooks',
    'reports' => 'View Reports'
];
