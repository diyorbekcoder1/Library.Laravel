<?php

return [
    'reports' => 'Reports',
    'most_viewed_ebooks' => 'Most Viewed eBooks',
    'pre_book_visitor' => 'Pre Books Visitor',
];
