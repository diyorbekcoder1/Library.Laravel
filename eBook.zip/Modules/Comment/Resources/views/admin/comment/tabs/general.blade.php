
{{ Form::text('comment', clean(trans('comment::attributes.comment')), $errors, $comment, ['required' => true]),  ['class' => 'form-control'] }}
