<?php

return [
    'comment' => 'Comment',

    'tabs' => [
        'comment' => 'Comment',
    ],
    'table' => [
        'user' => 'User',
        'comment' => 'Comments',
        'active' => 'Active',
        'activelink' => 'Active Link',
        'create_by' => 'Create By',
        'eBook' => 'eBook',
    ],
    'form' => [
        'enable_the_author' => 'Enable the Author',
        'verified_the_author' => 'Verified the Author. Only verified author profile visible at the front-end',
    ],
    
    'view_details' => 'View Details',
    'oldest' => 'Oldest',
];
