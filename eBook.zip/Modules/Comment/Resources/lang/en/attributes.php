<?php

return [
    'commenter_id' => 'Commenter Id',
    'commenter_type ' => 'Commenter Type ',
    'comment' => 'Comment',
    'active' => 'Active',
    'slug' => 'Slug',

];
