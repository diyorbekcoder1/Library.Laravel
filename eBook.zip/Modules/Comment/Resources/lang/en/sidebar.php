<?php

return [
    'comment' => 'Comment',
];
