<?php

return [
    'index' => 'Index Comment',
    'create' => 'Create Comment',
    'edit' => 'Edit Comment',
    'destroy' => 'Delete Comment',
];
