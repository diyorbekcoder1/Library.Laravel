<?php

return [
    'admin.comment' => [
        'index' => 'comment::permissions.index',
        'create' => 'comment::permissions.create',
        'edit' => 'comment::permissions.edit',
        'destroy' => 'comment::permissions.destroy',
    ],
];
