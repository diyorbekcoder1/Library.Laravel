<?php

return [
    'added' => 'This eBook has been added to your Favorite.',
];
